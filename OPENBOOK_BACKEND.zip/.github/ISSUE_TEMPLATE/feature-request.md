---
name: Feature request
about: 기능 개발을 위한 템플릿
title: "[FEAT]"
labels: feature
assignees: ''

---

## Description
<!-- 개발하고자 하는 기능에 대해 설명해주세요 -->

## TODO
<!-- 개발을 위해 해야 할 일을 작성해주세요 -->
- [ ]

## Reference
<!-- 참고 자료가 있다면 작성해주세요 -->

## Additional context
<!-- 추가적인 내용이 있다면 작성해주세요 -->
