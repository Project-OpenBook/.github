---
name: Fix request
about: 수정을 위한 템플릿
title: "[FIX]"
labels: fix
assignees: ''

---

## Description
<!-- 수정하고자 하는 내용에 대해 설명해주세요 -->

## TODO
<!-- 해야 할 일을 작성해주세요 -->
- [ ]

## Reference
<!-- 참고 자료나 bug issue가 있다면 작성해주세요 -->

## Additional context
<!-- 추가적인 내용이 있다면 작성해주세요 -->
