---
name: Suggest
about: 제안을 위한 템플릿
title: "[SUGGEST]"
labels: suggestion
assignees: ''

---

## Description
<!-- 제시하고자 하는 의견에 대해 설명해주세요 -->

## Reference
<!-- 참고 자료가 있다면 작성해주세요 -->

## Additional context
<!-- 추가적인 내용이 있다면 작성해주세요 -->
