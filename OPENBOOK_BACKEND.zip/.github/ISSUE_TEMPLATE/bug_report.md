---
name: Bug report
about: 버그 보고를 위한 템플릿
title: "[BUG]"
labels: bug
assignees: ''

---

## Describe the bug
<!-- 어떤 버그가 있는지 간단히 설명해주세요 -->

## Expected behavior
<!-- 정상 동작 시의 동작에 대해 간단히 설명해주세요 -->

## Screenshots
<!-- 참고할 수 있는 스크린샷이 있는 경우 추가해주세요 -->

## Additional context
<!-- 추가적인 내용이 있다면 작성해주세요 -->
