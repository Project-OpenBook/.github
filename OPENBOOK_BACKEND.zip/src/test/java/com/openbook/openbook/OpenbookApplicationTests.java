package com.openbook.openbook;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OpenbookApplicationTests {

	@Test
	void contextLoads() {
	}

}
