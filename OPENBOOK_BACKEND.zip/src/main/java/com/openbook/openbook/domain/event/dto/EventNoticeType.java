package com.openbook.openbook.domain.event.dto;

public enum EventNoticeType {
    BASIC,
    EVENT
}
