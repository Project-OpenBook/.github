package com.openbook.openbook.domain.booth.dto;


import lombok.Getter;

@Getter
public enum BoothAreaStatus {
    EMPTY,
    WAITING,
    COMPLETE
}
