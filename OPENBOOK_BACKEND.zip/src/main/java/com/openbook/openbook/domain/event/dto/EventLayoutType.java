package com.openbook.openbook.domain.event.dto;

import lombok.AllArgsConstructor;
import lombok.Getter;

@Getter
@AllArgsConstructor
public enum EventLayoutType {
    ALPHABET,
    NUMBER
}
