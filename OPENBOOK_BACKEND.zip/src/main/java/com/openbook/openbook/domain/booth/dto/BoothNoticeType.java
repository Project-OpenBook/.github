package com.openbook.openbook.domain.booth.dto;

public enum BoothNoticeType {
    BASIC,
    EVENT
}
