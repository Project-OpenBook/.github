package com.openbook.openbook.domain.user.dto;

public enum UserRole {
    ADMIN,
    USER
}
