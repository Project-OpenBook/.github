export const MAIN_BLUE = "#0064FF";
export const MAIN_RED = "#EF4444";
export const MAIN_BORDER = "#D1D5DB";
