export default function ServiceTimeInfoAdd() {
  return (
    <button className="flex flex-col font-bold h-10 rounded-md w-20 items-center justify-center bg-blue-500 text-bold ">
      <div> + </div>
    </button>
  );
}
