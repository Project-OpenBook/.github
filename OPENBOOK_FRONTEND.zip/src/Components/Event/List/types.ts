export type Progress = "진행중" | "모집중" | "종료된 행사";
